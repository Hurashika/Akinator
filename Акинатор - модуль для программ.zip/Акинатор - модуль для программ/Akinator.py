import json
import os

class Akinator:
    # Конструктор класса (Считывание данных с json)
    def __init__(self):
        if not os.path.exists('data.json'):
            self.create_json()
        with open("data.json", "r", encoding="UTF-8") as file_in:
            self.data = json.load(file_in)
        self.obj_prop = list()
    # Функция создания файла с заполнением первых 3-ёх таблиц
    def create_json(self):
        data = list()
        question = input("Напишите вопрос: ")
        yes_word = input("Введите слово, которое будет показываться при ответе 'да' на вопрос: ")
        no_word = input("Введите слово, которое будет показываться при ответе 'нет' на вопрос: ")
        property = input("Дайте ему свойство, которое можно выделить по заданному вопросу: ").lower()
        first_question = {
            "from": None,
            "definition": f"{question}",
            "yes": f"{yes_word}",
            "no": f"{no_word}",
            "property": f"{property}",
            "count": 0
            }
        new_leaf_yes = {
            "from": f"{question}",
            "definition": f"{yes_word}",
            "yes": None,
            "no": None,
            "property": None,
            "count": 1
            }
        new_leaf_no = {
            "from": f"{question}",
            "definition": f"{no_word}",
            "yes": None,
            "no": None,
            "property": None,
            "count": 1
            }
        data.append(first_question)
        data.append(new_leaf_yes)
        data.append(new_leaf_no)
        with open("data.json", "w", encoding="UTF-8") as file_out:
           json.dump(data, file_out, ensure_ascii=False, indent=2)
    # Функция задачи вопросов
    def ask_question(self, branch):
        if self.is_end(branch):
            print(f"Вы загадали: {branch['definition']}.\nЯ угадал?")
        else:
            print(branch['definition'])
    # Функция принятия ответов на вопросы
    def take_answer(self):
        while True:
            s = input().lower()
            if s == "да":
                return True
            elif s == "нет":
                return False
            else:
                print("Да или Нет?")
        return
    # Функция вывода свойств загаданного объекта
    def show_property(self, branch):
        self.obj_prop = list()
        temp = branch
        while branch['from'] != None:
            # переход к ветке элемента
            for i in self.data:
                if i["definition"] == branch["from"]:
                    temp = i
                    if i["yes"] == branch["definition"]:
                        branch = i
                        self.obj_prop.append(branch["property"])

            branch = temp
        s = ''
        for i in range(len(self.obj_prop)):
            if i == len(self.obj_prop) - 1:
                s += f"{self.obj_prop[i]}."
            else:
                s += f"{self.obj_prop[i]}, "
        print(f"Этот объект: " + s)
    # Функция вывода структуры данных акинатора
    def make_question_tree(self):
        lines = self.__pretty_print(self.first_question())
        for line in lines:
            print(line)
    # Функция итеративного построения строк уровня дерева
    def __pretty_print(self, branch, prefix="", is_left=True):
        # Проверка на конечный элемент дерева
        if branch["yes"] is None:
            current_line = f"{prefix}{'да|-- ' if is_left else 'нет|-- '}{branch["definition"]}"
            prefix += "   " if is_left else "   "
            return [current_line]

        # Подготовка текущей линии
        if branch["from"] is None:
            current_line = f"{prefix}|-- {branch["definition"]}"
        else:
            current_line = f"{prefix}{'да |-- ' if is_left else 'нет|-- '}{branch["definition"]}"
        prefix += "   " if is_left else "   "
        # Получаем все левые и правые ветви дерева
        left_lines = self.__pretty_print(self.next_branch(branch, True), prefix, True)
        right_lines = self.__pretty_print(self.next_branch(branch, False), prefix, False)
        # Соединяем все линии
        combined_lines = [current_line] + left_lines + right_lines
        return combined_lines
    # Функция поиска объекта в базе знаний
    def find_object(self):
        s = input("Введите искомый объект: ").lower()
        for i in self.data:
            if i["definition"].lower() == s:
                print(f"{s.upper()} есть в Базе Знаний")
                self.show_property(i)
                return
        print(f"{s.upper()} нет в Базе Знаний")
    # Функция добавления нового объекта (и вопрос к нему) в Базу Знаний
    def __add_object(self, branch):
        word = input("Введите слово, которое вы загадали: ")
        question = input("Напишите вопрос к нему, который будет\nотличать его от других: ")
        property = input("Дайте ему свойство, которое можно выделить по заданному вопросу: ").lower()
        temp_word = branch["definition"]
        count = branch["count"]
        new_leaf_yes = {
            "from": f"{question}",
            "definition": f"{word}",
            "yes": None,
            "no": None,
            "property": None,
            "count": 1
            }
        new_leaf_no = {
            "from": f"{question}",
            "definition": f"{temp_word}",
            "yes": None,
            "no": None,
            "property": None,
            "count": count
            }
        branch["definition"] = question
        branch["yes"] = new_leaf_yes["definition"]
        branch["no"] = new_leaf_no["definition"]
        branch["property"] = property
        branch["count"] = 0
        for i in self.data:
            if i["definition"] == branch['from']:
                if i["yes"] == temp_word:
                    i["yes"] = branch["definition"]
                else:
                    i["no"] = branch["definition"]
        self.data.append(new_leaf_yes)
        self.data.append(new_leaf_no)
        self.update_data()
    #Отгадывает объект, который был загадан больше всего раз, если правильно, то выходит из всех методов 
    def first_guess(self):
        word = ''
        maxi = 0
        index = 0
        for i in range(len(self.data)):
            if self.data[i]["count"] > maxi:
                maxi = self.data[i]["count"]
                word = self.data[i]['definition']
                index = i
        print(f"Вы загадали {word}. Я угадал? (да\нет)")
        while True:
            s = input().lower()
            if s == "да":
                print("Ура, я угадал ( ͡° ͜ʖ ͡°)")
                self.show_property(self.data[index])
                self.data[index]["count"] += 1
                self.update_data()
                return True
            elif s == "нет":
                print("Хорошо, продолжим отгадывать")
                return False
            else:
                print("Да или Нет?")
    # Первый элемент базы знаний
    def first_question(self):
        return self.data[0]
    # Проверка на то, что это лист дерева, а не ветка
    def is_end(self, branch):
        if branch['yes'] is None and branch["no"] is None:
            return True
        return False
    # Переход на следующую ветку (лист)
    def next_branch(self, branch, answer=False):
        for i in self.data:
            if (i["definition"] == branch["yes"]) & answer:
                return i
            elif i["definition"] == branch["no"]:
                return i
    # функция отгадывания
    def guessing(self):
        branch = self.first_question()
        exit = self.first_guess()
        if exit:
            return
        
        self.ask_question(branch)
        while True:
            #print(branch)
            if self.take_answer():
                final = self.is_end(branch)
                if final:
                    print("Ура я угадал ( ͡° ͜ʖ ͡°)")
                    self.show_property(branch)
                    branch["count"] += 1
                    self.update_data()
                    # Должен быть ещё код
                    return
                branch = self.next_branch(branch, True)
            else:
                final = self.is_end(branch)
                if final:
                    print("Я не знаю того, что вы загадали (ಠ_ಠ)\nПожалуйста заполните поля нового объекта:")
                    self.__add_object(branch)
                    return
                branch = self.next_branch(branch, False)
            self.ask_question(branch)
    # Обновление json после внесённых изменений
    def update_data(self):
        with open("data.json", "w", encoding="UTF-8") as file_out:
           json.dump(self.data, file_out, ensure_ascii=False, indent=2)
        #print(self.data)

def main():
    akinator = Akinator()
    print("Здравствуйте, для начала выберите режим работы:")
    while True:
        print("\n\n1. Просмотр базы данных системы\n2. Поиск объекта по названию\n3. Отгадывание загаданного слова\n(Выбирайте: 'просмотр', 'поиск', 'игра', либо 'конец' для выхода)")
        f = True
        s = input().lower()
        match s:
            case 'просмотр':
                akinator.make_question_tree()
            case 'поиск':
                akinator.find_object()
            case 'игра':
                akinator.guessing()
            case 'конец':
                f = False
            case _:
                print("Выбирайте: 'просмотр', 'поиск', 'игра', либо 'конец' для выхода")
        if f == False:
            break
    return

# Если это модуль программы, то main() не будет запускаться
if __name__ == '__main__':
    main()
